create definer = `mariadb.sys`@localhost view ps_check_lost_instrumentation as
select `performance_schema`.`global_status`.`VARIABLE_NAME`  AS `variable_name`,
       `performance_schema`.`global_status`.`VARIABLE_VALUE` AS `variable_value`
from `performance_schema`.`global_status`
where `performance_schema`.`global_status`.`VARIABLE_NAME` like 'perf%lost'
  and `performance_schema`.`global_status`.`VARIABLE_VALUE` > 0;

-- comment on column ps_check_lost_instrumentation.variable_name not supported: The global status variable name.

-- comment on column ps_check_lost_instrumentation.variable_value not supported: The global status variable value.

